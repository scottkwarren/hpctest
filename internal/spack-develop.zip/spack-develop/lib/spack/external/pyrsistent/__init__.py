# -*- coding: utf-8 -*-

from pyrsistent._pmap import pmap


__all__ = ('pmap',)
