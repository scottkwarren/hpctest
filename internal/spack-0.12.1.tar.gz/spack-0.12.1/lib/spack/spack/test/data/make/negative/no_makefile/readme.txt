# Tests that Spack ignores directories without a Makefile

check:
