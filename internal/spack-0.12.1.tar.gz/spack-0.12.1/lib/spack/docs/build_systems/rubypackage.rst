.. Copyright 2013-2019 Lawrence Livermore National Security, LLC and other
   Spack Project Developers. See the top-level COPYRIGHT file for details.

   SPDX-License-Identifier: (Apache-2.0 OR MIT)

.. _rubypackage:

-----------
RubyPackage
-----------

Like Perl, Python, and R, Ruby has its own build system for
installing Ruby gems.

This build system is a work-in-progress. See
https://github.com/spack/spack/pull/3127 for more information.
