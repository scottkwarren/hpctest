#!/bin/sh
# convenience wrapper for the jar file
java $JAVA_ARGS $JAVA_OPTS -jar beagle.jar "$@"

