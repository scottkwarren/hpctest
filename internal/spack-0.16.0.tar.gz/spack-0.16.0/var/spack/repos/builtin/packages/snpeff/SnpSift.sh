#!/bin/sh
# convenience wrapper for the SnpSift jar file
java -jar SnpSift.jar "$@"
