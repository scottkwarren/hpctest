#!/bin/sh
# convenience wrapper for the picard womtool jar file
java -jar womtool.jar "$@"
