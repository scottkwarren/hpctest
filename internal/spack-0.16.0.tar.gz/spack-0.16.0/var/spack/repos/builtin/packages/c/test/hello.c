#include <stdio.h>
int main()
{
	printf ("Hello world from C!\n");
	printf ("YES!");
	return 0;
}
