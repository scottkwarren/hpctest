#!/bin/sh
# convenience wrapper for the snpEff jar file
java -jar snpEff.jar "$@"
