# Mock GPG directory

This directory contains keys and data used in the testing Spack.
