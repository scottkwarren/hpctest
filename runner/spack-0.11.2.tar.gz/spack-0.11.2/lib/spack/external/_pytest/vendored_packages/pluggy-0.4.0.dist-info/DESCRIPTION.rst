
Plugin registration and hook calling for Python
===============================================

This is the plugin manager as used by pytest but stripped
of pytest specific details.

During the 0.x series this plugin does not have much documentation
except extensive docstrings in the pluggy.py module.


